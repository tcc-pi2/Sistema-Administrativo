# Totem Lanche Admin

Painel administrativo para controlar o cardapio de um totem de autoatendimento em uma lanchonete.

## Ideia do projeto

O sistema resolve um problema simples e real: a lanchonete precisa alterar produtos, precos, categorias e disponibilidade do cardapio sem mexer diretamente no totem. O cliente usa o totem para escolher o lanche; o administrador usa este painel para manter o cardapio organizado.

## Para que serve

- Cadastrar e consultar itens do cardapio.
- Organizar categorias como combos, bebidas, sobremesas e adicionais.
- Controlar estoque/disponibilidade dos itens exibidos no totem.
- Registrar pedidos feitos pelo cliente no autoatendimento.
- Permitir que o cliente acompanhe a situacao do pedido pelo codigo de retirada.
- Acompanhar a fila da cozinha e atualizar o status do pedido.
- Acompanhar faturamento, formas de pagamento e caixa do dia.
- Configurar no dashboard o tempo de espera exibido ao cliente.
- Administrar usuarios com acesso ao painel.
- Preparar a base para conectar PHP e MySQL.

## Como explicar na apresentacao

> Este projeto simula um fluxo real de lanchonete: o cliente faz o pedido no totem, a cozinha acompanha a fila de preparo e o administrador controla o cardapio, categorias, estoque e usuarios do sistema. Se um lanche acaba, ele deixa de aparecer no totem. Se o preco muda, o painel atualiza a informacao. Quando o cliente finaliza o pedido, ele recebe um codigo de retirada e a cozinha consegue avancar o status.

Fluxo principal:

1. Cliente escolhe os produtos no totem.
2. Totem gera um pedido com codigo de retirada.
3. Cliente acompanha a situacao do pedido pelo codigo.
4. Cozinha recebe o pedido e atualiza o status: recebido, em preparo, pronto e retirado.
5. Administrador acompanha indicadores no dashboard.
6. Administrador acompanha financeiro, caixa, produtos, categorias, estoque e acessos.

## Tecnologias usadas

- HTML5
- CSS3
- JavaScript
- Font Awesome para icones
- MySQL/MariaDB como modelo de banco em `database.sql`

## Funcionalidades prontas

- Login obrigatório para o painel administrativo.
- Cadastro, edição e exclusão de itens do cardápio.
- Cadastro, edição e exclusão de categorias.
- Cadastro, edição, bloqueio e exclusão de administradores.
- Totem do cliente com categorias, carrinho, pagamento simulado e código de retirada.
- Consulta de situacao do pedido no totem pelo codigo de retirada.
- Pedidos do totem salvos e exibidos no dashboard.
- Tela da cozinha para acompanhar e avancar o status dos pedidos.
- Tela financeira com faturamento, caixa, entradas, saidas e vendas por pagamento.
- Configuracao de tempo medio de espera pelo painel administrativo.
- Estoque atualizado quando um pedido é finalizado.
- Exportação CSV de cardápio, categorias, administradores e financeiro.

Os dados ficam salvos no navegador usando `localStorage`, então o projeto funciona mesmo sem servidor PHP. O arquivo `database.sql` já deixa a estrutura pronta para uma futura integração com MySQL.

## Melhorias visuais

- Animacao de entrada das telas.
- Contadores animados no dashboard.
- Linhas de tabela com entrada suave.
- Feedback por notificacoes na tela.
- Efeito visual nos botoes.
- Padrao unico de icones e componentes.

## Telas

- Login
- Dashboard do totem
- Financeiro e caixa
- Produtos do cardapio
- Categorias
- Adicionar categoria
- Editar categoria
- Confirmar exclusao
- Administradores
- Totem do cliente com carrinho
- Cozinha/atendimento com fila de pedidos

## Acesso de teste

```text
Usuario: admin
Senha: 123
```

## Acesso administrativo

O totem do cliente fica aberto para simular o autoatendimento. Ja o painel administrativo exige login: ao tentar abrir dashboard, cozinha, financeiro, cardapio, categorias ou administradores sem sessao ativa, o sistema redireciona para `login.html`.

O botao **Sair** encerra a sessao e volta para a tela de login.

## Como abrir

Abra o arquivo:

```text
gerenciador_pi/index.html
```

O `index.html` abre o totem do cliente. Pelo link **Painel administrativo**, o sistema pede login antes de abrir o dashboard.

Tambem e possivel colocar a pasta `gerenciador_pi` dentro do `htdocs` do XAMPP e acessar pelo navegador.

## Banco de dados

O arquivo `database.sql` contem uma estrutura inicial com:

- administradores
- configuracoes_sistema
- caixas
- movimentos_caixa
- categorias
- produtos
- pedidos
- itens_pedido

## Totem do cliente

A tela `gerenciador_pi/pages/totem.html` simula a parte que o cliente usaria no autoatendimento:

- filtro por categorias;
- cards de lanches e bebidas;
- carrinho com quantidade;
- forma de pagamento simulada;
- confirmacao com codigo de retirada;
- acompanhamento da situacao do pedido com barra de progresso.

Quando o pedido e confirmado, ele aparece no dashboard e na tela `gerenciador_pi/pages/cozinha.html`. No proprio totem, o cliente pode tocar em **Acompanhar pedido** e consultar o status usando o codigo de retirada.

O tempo de espera mostrado ao cliente e configurado no dashboard, pelo botao de engrenagem ou pelo botao **Ajustar** no card de tempo medio.

## Cozinha/atendimento

A tela `gerenciador_pi/pages/cozinha.html` representa a area interna da lanchonete:

- filtra pedidos por status;
- mostra codigo, cliente, itens e total;
- avanca o pedido de recebido para em preparo, pronto e retirado;
- ajuda a explicar a utilidade pratica do sistema durante a apresentacao.

## Financeiro

A tela `gerenciador_pi/pages/financeiro.html` representa o controle de caixa:

- mostra faturamento do dia usando os pedidos do totem;
- separa vendas por Pix, cartao e dinheiro;
- calcula o saldo atual do caixa com saldo inicial, entradas e saidas;
- permite registrar movimentos manuais, como reforco de troco ou compra de embalagens;
- exporta os dados financeiros em CSV.

Para usar no phpMyAdmin:

1. Abra o phpMyAdmin.
2. Clique em Importar.
3. Selecione o arquivo `database.sql`.
4. Execute a importacao.

## Proxima etapa

Esta versao esta funcional no navegador com `localStorage`. A proxima etapa, se o professor exigir backend, e transformar as telas em PHP, conectar com MySQL e substituir o armazenamento local pelo banco.
