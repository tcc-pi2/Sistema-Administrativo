const AUTH_KEY = "totemLancheAdminAutenticado";

if (localStorage.getItem(AUTH_KEY) !== "true") {
  window.location.replace("./login.html?next=cozinha.html");
}

let filtroAtual = "Todos";
const filtros = ["Todos", "Recebido", "Em preparo", "Pronto", "Retirado"];

function dinheiro(valor) {
  return TotemStore.money(valor);
}

function badgeClass(status) {
  if (status === "Recebido") return "badge badge--received";
  if (status === "Em preparo") return "badge badge--preparing";
  if (status === "Pronto") return "badge badge--ready";
  return "badge badge--done";
}

function proximoStatus(status) {
  const fluxo = ["Recebido", "Em preparo", "Pronto", "Retirado"];
  const index = fluxo.indexOf(status);
  return fluxo[Math.min(index + 1, fluxo.length - 1)];
}

function textoAcao(status) {
  if (status === "Recebido") return "Iniciar preparo";
  if (status === "Em preparo") return "Marcar pronto";
  if (status === "Pronto") return "Confirmar retirada";
  return "Finalizado";
}

function renderTabs() {
  const wrapper = document.querySelector("[data-status-tabs]");
  const pedidos = TotemStore.load().orders;

  wrapper.innerHTML = filtros.map((filtro) => {
    const total = filtro === "Todos" ? pedidos.length : pedidos.filter((pedido) => pedido.status === filtro).length;
    return `
      <button class="tab-button ${filtro === filtroAtual ? "is-active" : ""}" type="button" data-filter="${filtro}">
        ${filtro} (${total})
      </button>
    `;
  }).join("");

  wrapper.querySelectorAll("[data-filter]").forEach((botao) => {
    botao.addEventListener("click", () => {
      filtroAtual = botao.dataset.filter;
      renderCozinha();
    });
  });
}

function renderPedidos() {
  const board = document.querySelector("[data-orders-board]");
  const pedidos = TotemStore.load().orders
    .filter((pedido) => filtroAtual === "Todos" || pedido.status === filtroAtual)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  if (!pedidos.length) {
    board.innerHTML = `
      <div class="empty-state">
        <span>
          <i class="fa-solid fa-clipboard-check"></i><br><br>
          Nenhum pedido nessa etapa
        </span>
      </div>
    `;
    return;
  }

  board.innerHTML = pedidos.map((pedido, index) => `
    <article class="order-card" style="animation-delay: ${index * 45}ms">
      <div class="order-card__header">
        <div>
          <span class="order-code">${pedido.code}</span>
        </div>
        <span class="${badgeClass(pedido.status)}">${pedido.status}</span>
      </div>

      <div>
        <h2>${pedido.customer}</h2>
        <p>${pedido.payment} • ${pedido.prepTime} min estimados</p>
      </div>

      <div class="order-items">
        ${pedido.items.map((item) => `
          <div class="order-item">
            <span>${item.quantity}x ${item.name}</span>
            <strong>${dinheiro(item.price * item.quantity)}</strong>
          </div>
        `).join("")}
      </div>

      <div class="order-card__footer">
        <span class="order-total">${dinheiro(pedido.total)}</span>
        <button class="button button--primary" type="button" data-next="${pedido.id}" ${pedido.status === "Retirado" ? "disabled" : ""}>
          ${textoAcao(pedido.status)}
        </button>
      </div>
    </article>
  `).join("");

  board.querySelectorAll("[data-next]").forEach((botao) => {
    botao.addEventListener("click", () => {
      const pedido = TotemStore.load().orders.find((item) => item.id === Number(botao.dataset.next));
      if (!pedido) return;

      const status = proximoStatus(pedido.status);
      TotemStore.updateOrderStatus(pedido.id, status);
      mostrarToast(`Pedido ${pedido.code}: ${status}`);
      renderCozinha();
    });
  });
}

function mostrarToast(texto) {
  const atual = document.querySelector(".toast");
  if (atual) atual.remove();

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = texto;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2200);
}

function renderCozinha() {
  renderTabs();
  renderPedidos();
}

document.addEventListener("DOMContentLoaded", () => {
  document.body.classList.add("ready");
  renderCozinha();
});
